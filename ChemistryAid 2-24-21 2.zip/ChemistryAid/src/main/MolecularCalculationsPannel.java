package main;

import java.awt.*;
import javax.swing.*;

public class MolecularCalculationsPannel extends JPanel {
	private static final long serialVersionUID = 839363422441511153L;
	
	private JFrame jf;

	public MolecularCalculationsPannel( JFrame jframe) {
		jf = jframe;
		startUp();
	}
	
	protected void startUp() {
		setBackground(Color.LIGHT_GRAY);
	}

}