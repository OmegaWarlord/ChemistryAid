package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PeriodicTablePannel extends JPanel{
	private static final long serialVersionUID = 1L;
	
	private JFrame jf;
	
	public PeriodicTablePannel(JFrame jframe) {
		jf = jframe;
		startUp();
	}
	
	protected void startUp() {
		int i = 10;
		int j = 18;
		GridLayout gl = new GridLayout(i,j);
		JPanel[][] ph = new JPanel[i][j];    
		setLayout(gl);
		setBackground(Color.LIGHT_GRAY);

		for(int m = 0; m < i; m++) {
		   for(int n = 0; n < j; n++) {
		      ph[m][n] = new JPanel();
		      ph[m][n].setBorder(BorderFactory.createLineBorder(Color.GRAY));
		      ph[m][n].setBackground(Color.LIGHT_GRAY);
		      add(ph[m][n]);
		   }
		}
		
		
		//Element Creation Block
		ep(ph[0][0], "Hydrogen", "H", "1", "1.008", "0.0899", "1", Color.GREEN);
		ep(ph[0][17], "Helium", "He", "2", "4.0026", "0.1785","2", Color.MAGENTA);
		
		ep(ph[1][0], "Lithium", "Li", "3", "6.94", "535","2,1", Color.ORANGE);
		ep(ph[1][1], "Beryllium", "Be", "4", "9.0122", "1,848", "2,2", Color.YELLOW);
		ep(ph[1][12], "Boron", "B", "5", "10.81", "2,460", "2,3", Color.CYAN);
		ep(ph[1][13], "Carbon", "C", "6", "12.011", "2,260", "2,4", Color.GREEN);
		ep(ph[1][14], "Nitrogen", "N", "7", "14.007", "1,251", "2,5", Color.GREEN);
		ep(ph[1][15], "Oxygen", "O", "8", "15.999", "1,429", "2,6", Color.GREEN);
		ep(ph[1][16], "Fluorine", "F", "9", "18.998", "1,696", "2,7", Color.GREEN);
		ep(ph[1][17], "Neon", "Ne", "10", "20.180", "0.900", "2,8", Color.MAGENTA);
		
		ep(ph[2][0], "Sodium", "Na", "11", "22.990", "968","2,8,1", Color.ORANGE);
		ep(ph[2][1], "Magnesium", "Mg", "12", "24.305", "1,738", "2,8,2", Color.YELLOW);
		ep(ph[2][12], "Aluminium", "Al", "13", "26.982", "2,700", "2,8,3", Color.BLUE);
		ep(ph[2][13], "Silicon", "Si", "14", "28.085", "2,330", "2,8,4", Color.CYAN);
		ep(ph[2][14], "Phosphorus", "P", "15", "30.974", "1,832", "2,8,5", Color.GREEN);
		ep(ph[2][15], "Sulfur", "S", "16", "32.06", "1,960", "2,8,6", Color.GREEN);
		ep(ph[2][16], "Clorine", "Cl", "17", "35.45", "3.214", "2,8,7", Color.GREEN);
		ep(ph[2][17], "Argon", "Ar", "18", "39.948", "1.784", "2,8,8,", Color.MAGENTA);
		
		ep(ph[3][0], "Potassium", "K", "19", "39.098", "856", "2,8,8,1", Color.ORANGE);
		ep(ph[3][1], "Calcium", "Ca", "20", "40.078", "1,550", "2,8,8,2", Color.YELLOW);
		ep(ph[3][2], "Scandium", "Sc", "21", "44.956", "2,985", "2,8,9,2", Color.PINK);
		ep(ph[3][3], "Titanium", "Ti", "22", "47.867", "4,507", "2,8,10,2", Color.PINK);
		ep(ph[3][4], "Vanadium", "V", "23", "50.942", "6,110", "2,8,11,2", Color.PINK);
		ep(ph[3][5], "Chromium", "Cr", "24", "51.996", "7,190", "2,8,13,1", Color.PINK);
		ep(ph[3][6], "Mangenese", "Mn", "25", "54.938", "7,470", "2,8,13,2", Color.PINK);
		ep(ph[3][7], "Iron", "Fe", "26", "55.845", "7,874", "2,8,14,2", Color.PINK);
		ep(ph[3][8], "Cobalt", "Co", "27", "58.933", "8,900", "2,8,15,2", Color.PINK);
		ep(ph[3][9], "Nickel", "Ni", "28", "58.693", "8,908", "2,8,16,2", Color.PINK);
		ep(ph[3][10], "Copper", "Cu", "29", "63.546", "8,960", "2,8,18,1", Color.PINK);
		ep(ph[3][11], "Zinc", "Zn", "30", "65.38", "7,140", "2,8,18,2", Color.PINK);
		ep(ph[3][12], "Gallium", "Ga", "31", "69.723", "5,904", "2,8,18,3", Color.BLUE);
		ep(ph[3][13], "Germanium", "Ga", "32", "72.630", "5,323", "2,8,18,4", Color.CYAN);
		ep(ph[3][14], "Arsenic", "As", "33", "74.922", "5,727", "2,8,18,5", Color.CYAN);
		ep(ph[3][15], "Selenium", "Se", "34", "78.971", "4,819", "2,8,18,6", Color.GREEN);
		ep(ph[3][16], "Bromine", "Br", "35", "79.904", "3,120", "2,8,18,7", Color.GREEN);
		ep(ph[3][17], "Krypton", "Kr", "36", "83.798", "3.75", "2,8,18,8", Color.MAGENTA);
		
		ep(ph[4][0], "Rubidium", "Rb", "37", "85.468", "1,532", "2,8,18,8,1", Color.ORANGE);
		ep(ph[4][1], "Strontium", "Sr", "38", "87.62", "2,630", "2,8,18,8,2", Color.YELLOW);
		ep(ph[4][2], "Yttrium", "Y", "39", "88.906", "4,472", "2,8,18,9,2", Color.PINK);
		ep(ph[4][3], "Zirconium", "Zr", "40", "91.224", "6,511", "2,8,18,10,2", Color.PINK);
		ep(ph[4][4], "Niobium", "Nb", "41", "92.906", "8,570", "2,8,18,12,1", Color.PINK);
		ep(ph[4][5], "Molybdenum", "Mo", "42", "95.95", "10,280", "2,8,18,13,1", Color.PINK);
		
		ep(ph[4][14], "Antimony", "Sb", "51", "121.76", "6,697", "2,8,18,18,4", Color.CYAN);
		ep(ph[4][15], "Tellurium", "Te", "52", "127.60", "6,240", "2,8,18,18,6", Color.CYAN);
		ep(ph[4][16], "Iodine", "I", "53", "126.90", "4,940", "2,8,18,18,7", Color.GREEN);
		ep(ph[4][17], "Xenon", "Xe", "54", "131.29", "5.9", "2,8,18,18,8", Color.MAGENTA);
		
		ep(ph[5][0], "Caesium", "Cs", "55", "132.91", "1,879", "2,8,18,18,8,1", Color.ORANGE);
		ep(ph[5][1], "Barium", "Ba", "56", "137.33", "3,510", "2,8,18,18,8,2", Color.YELLOW);
		
		epa(ph[5][16], "Astatine", "At", "85", "(210)", "2,8,18,32,18,7", Color.CYAN);
		epa(ph[5][17], "Radon", "Rn", "86", "(222)", "2,8,18,32,18,8", Color.MAGENTA);

		epa(ph[6][0], "Francium", "Fr", "87", "(223)", "2,8,18,32,18,8,1", Color.ORANGE);
		epa(ph[6][1], "Radium", "Ra", "88", "(226)", "2,8,18,32,18,8,2", Color.YELLOW);
	}
	
	protected void ep(JPanel panel, String name, String sym, String num, String weight, String denisty, String energy, Color color) {
		GridLayout gl = new GridLayout(4,1);
		panel.setLayout(gl);
		panel.setBackground(color);
		
		JLabel an = new JLabel(num);
		an.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel as = new JLabel(sym);
		as.setFont(new Font("Monaco", Font.BOLD, 15));
		
		JLabel nm = new JLabel(name);
		nm.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel am = new JLabel(weight);
		am.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		panel.add(an);
		panel.add(as);
		panel.add(nm);
		panel.add(am);
		
		panel.addMouseListener(new MouseAdapter() { 
			public void mousePressed(MouseEvent me) { 
				System.out.println(me); 
				
				 JPopupMenu pop = new JPopupMenu();
				 GridLayout gl2 = new GridLayout(4,2);
				 JPanel jp = new JPanel();
				 jp.setLayout(gl2);
				 
				 JLabel nm = new JLabel(name);
				 nm.setFont(new Font("Monaco", Font.BOLD, 15));
				 
				 JLabel an = new JLabel(num, SwingConstants.RIGHT);
				 an.setFont(new Font("Monaco", Font.BOLD, 20));
				 
				 JLabel ml = new JLabel("Atomic Mass:", SwingConstants.LEFT);
				 ml.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel am = new JLabel(weight +"g", SwingConstants.RIGHT);
				 am.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel ell = new JLabel("Energy Levels:", SwingConstants.LEFT);
				 ell.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel el = new JLabel(energy, SwingConstants.RIGHT);
				 el.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel dl = new JLabel("Density:", SwingConstants.LEFT);
				 dl.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel de = new JLabel(denisty+"kg/m^3", SwingConstants.RIGHT);
				 de.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 jp.add(nm);
				 jp.add(an);
				 jp.add(ml);
				 jp.add(am);
				 jp.add(ell);
				 jp.add(el);
				 jp.add(dl);
				 jp.add(de);
				 pop.add(jp);
				 
				 pop.show(jf, panel.getX() + 65, panel.getY() + 56);
	        } 
	    }); 
	}	
	protected void epa(JPanel panel, String name, String sym, String num, String weight, String energy, Color color) {
		GridLayout gl = new GridLayout(4,1);
		panel.setLayout(gl);
		panel.setBackground(color);
		
		JLabel an = new JLabel(num);
		an.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel as = new JLabel(sym);
		as.setFont(new Font("Monaco", Font.BOLD, 15));
		
		JLabel nm = new JLabel(name);
		nm.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel am = new JLabel(weight);
		am.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		panel.add(an);
		panel.add(as);
		panel.add(nm);
		panel.add(am);
		
		panel.addMouseListener(new MouseAdapter() { 
			public void mousePressed(MouseEvent me) { 
				System.out.println(me); 
				
				 JPopupMenu pop = new JPopupMenu();
				 GridLayout gl2 = new GridLayout(4,2);
				 JPanel jp = new JPanel();
				 jp.setLayout(gl2);
				 
				 JLabel nm = new JLabel(name);
				 nm.setFont(new Font("Monaco", Font.BOLD, 15));
				 
				 JLabel an = new JLabel(num, SwingConstants.RIGHT);
				 an.setFont(new Font("Monaco", Font.BOLD, 20));
				 
				 JLabel ml = new JLabel("Atomic Mass:", SwingConstants.LEFT);
				 ml.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel am = new JLabel("N/A", SwingConstants.RIGHT);
				 am.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel ell = new JLabel("Energy Levels:", SwingConstants.LEFT);
				 ell.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel el = new JLabel(energy, SwingConstants.RIGHT);
				 el.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel dl = new JLabel("Density:", SwingConstants.LEFT);
				 dl.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 JLabel de = new JLabel("N/A", SwingConstants.RIGHT);
				 de.setFont(new Font("Monaco", Font.PLAIN, 15));
				 
				 jp.add(nm);
				 jp.add(an);
				 jp.add(ml);
				 jp.add(am);
				 jp.add(ell);
				 jp.add(el);
				 jp.add(dl);
				 jp.add(de);
				 pop.add(jp);
				 
				 pop.show(jf, panel.getX() + 65, panel.getY() + 56);
	        } 
	    }); 
	}
}