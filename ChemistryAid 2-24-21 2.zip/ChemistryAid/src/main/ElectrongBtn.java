package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ElectrongBtn extends JButton {
	private static final long serialVersionUID = 1354327633331256472L;
	
	private boolean active, active2 = false;

	public ElectrongBtn() {
		setBackground(Color.WHITE);
		addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(active2){
					active2 = false;
					setBackground(Color.LIGHT_GRAY);
				} else if (active) {
					active2 = true;
					setBackground(Color.GRAY);
				} else {
					active = true;
					setBackground(Color.LIGHT_GRAY);
				}
				
			}
		});
	}
	
	public void deactivate() {
		active = false; active2 = false; 
		setBackground(Color.WHITE);
	} public void activate() {
		active = true; active2 = false; 
		setBackground(Color.LIGHT_GRAY);
	} public void activate2() {
		active = true; active2 = true; 
		setBackground(Color.GRAY);
	} public boolean getState() {
		return active;
	} public boolean getState2() {
		return active2;
	}
}