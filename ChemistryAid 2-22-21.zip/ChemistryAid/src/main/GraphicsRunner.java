package main;

import javax.swing.*;
import java.awt.event.KeyEvent;



public class GraphicsRunner extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private static final int WIDTH = 1000;
	private static final int HEIGHT = 600;
	
	private JTabbedPane tp;
	private PeriodicTablePannel pt;


	
	public GraphicsRunner(){
		super("Graphics Runner");
		setSize(WIDTH,HEIGHT);
		
		tp = new JTabbedPane();
		pt = new PeriodicTablePannel();
		tp.addTab("Periodic Table", null, pt, "Period Table");
		tp.setMnemonicAt(0, KeyEvent.VK_1);
		tp.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		
		add(tp);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	/* protected JComponent makeTextPanel(String text) {
        JPanel panel = new JPanel(false);
        JLabel filler = new JLabel(text);
        filler.setHorizontalAlignment(JLabel.CENTER);
        panel.setLayout(new GridLayout(1, 1));
        panel.add(filler);
        return panel;
    } */
}


