package main;

import javax.swing.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

public class PeriodicTablePannel extends JPanel{

	private static final long serialVersionUID = 1L;

	public PeriodicTablePannel() {
		
		int i = 10;
		int j = 18;
		GridLayout gl = new GridLayout(i,j);
		JPanel[][] panelHolder = new JPanel[i][j];    
		setLayout(gl);

		for(int m = 0; m < i; m++) {
		   for(int n = 0; n < j; n++) {
		      panelHolder[m][n] = new JPanel();
		      panelHolder[m][n].setBorder(BorderFactory.createBevelBorder(1));
		      panelHolder[m][n].setSize(new Dimension(50,50));
		      add(panelHolder[m][n]);
		   }
		}
		Hydrogen(panelHolder[0][0]);
		Helium(panelHolder[0][17]);
		Lithium(panelHolder[1][0]);
		
	}
	
	protected void Hydrogen(JPanel panel) {
		GridLayout gl = new GridLayout(4,1);
		panel.setLayout(gl);
		panel.setBackground(Color.GREEN);
		
		JLabel an = new JLabel("1");
		an.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel as = new JLabel("H");
		as.setFont(new Font("Monaco", Font.BOLD, 15));
		
		JLabel nm = new JLabel("Hydrogen");
		nm.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel am = new JLabel("1.008");
		am.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		panel.add(an);
		panel.add(as);
		panel.add(nm);
		panel.add(am);
		
	}
	
	protected void Helium(JPanel panel) {
		GridLayout gl = new GridLayout(4,1);
		panel.setLayout(gl);
		panel.setBackground(Color.PINK);
		
		JLabel an = new JLabel("2");
		an.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel as = new JLabel("He");
		as.setFont(new Font("Monaco", Font.BOLD, 15));
		
		JLabel nm = new JLabel("Helium");
		nm.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel am = new JLabel("4.0026");
		am.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		panel.add(an);
		panel.add(as);
		panel.add(nm);
		panel.add(am);
	}
	
	protected void Lithium(JPanel panel) {
		GridLayout gl = new GridLayout(4,1);
		panel.setLayout(gl);
		panel.setBackground(Color.ORANGE);
		
		JLabel an = new JLabel("3");
		an.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel as = new JLabel("Li");
		as.setFont(new Font("Monaco", Font.BOLD, 15));
		
		JLabel nm = new JLabel("Lithium");
		nm.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		JLabel am = new JLabel("6.94");
		am.setFont(new Font("Monaco", Font.PLAIN, 10));
		
		panel.add(an);
		panel.add(as);
		panel.add(nm);
		panel.add(am);
	}
}
