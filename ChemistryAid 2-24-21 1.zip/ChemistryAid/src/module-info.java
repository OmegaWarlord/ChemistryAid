module ChemistryAid {
	requires java.desktop;
}