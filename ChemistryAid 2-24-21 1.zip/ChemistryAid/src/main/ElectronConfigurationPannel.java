package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class ElectronConfigurationPannel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	private int curEle = 0;

	private JFrame jf;
	private JLabel jl3;
	private ElectrongBtn[] btns = {
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(), new ElectrongBtn(),
			new ElectrongBtn(),
	};
	
	public ElectronConfigurationPannel(JFrame jframe) {
		jf = jframe;
		startUp();
	}
	
	protected void startUp() {
		int i = 7;
		int j = 20;
		setBackground(Color.LIGHT_GRAY);
		
		BoxLayout bl = new BoxLayout(this, BoxLayout.Y_AXIS);
		GridLayout gl = new GridLayout(i, j);
		
		JPanel jp1 = new JPanel();
		jp1.setLayout(gl);
		
		JPanel[][] ph = new JPanel[i][j];
		
		for(int m = 0; m < i; m++) {
			for(int n = 0; n < j; n++) {
				ph[m][n] = new JPanel();
				ph[m][n].setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
				ph[m][n].setBackground(Color.LIGHT_GRAY);
				ph[m][n].setLayout(new BorderLayout());
				jp1.add(ph[m][n]);
			}
		}
		int p = 0;
		for(int n = 1; n < 8 ; n++) {
			JLabel jl2 = new JLabel(""+n+"s");
			jl2.setFont(new Font("Monoco", Font.BOLD, 40));
			ph[p][0].add(jl2);
			p += 1;
		}
		p = 1;
		for(int n = 2; n < 8 ; n++) {
			JLabel jl2 = new JLabel(""+n+"p");
			jl2.setFont(new Font("Monoco", Font.BOLD, 40));
			ph[p][16].add(jl2);
			p += 1;
		}
		p = 3;
		for(int n = 3; n < 7 ; n++) {
			JLabel jl2 = new JLabel(""+n+"d");
			jl2.setFont(new Font("Monoco", Font.BOLD, 40));
			ph[p][10].add(jl2);
			p += 1;
		}
		p = 5;
		for(int n = 4; n < 6 ; n++) {
			JLabel jl2 = new JLabel(""+n+"f");
			jl2.setFont(new Font("Monoco", Font.BOLD, 40));
			ph[p][2].add(jl2);
			p += 1;
		}
		ph[0][1].add(btns[0], BorderLayout.CENTER);
		action(btns[0],1);

		ph[1][1].add(btns[1], BorderLayout.CENTER);
		action(btns[1],2);
		
		ph[1][17].add(btns[2], BorderLayout.CENTER);
		action(btns[2],3);

		ph[1][18].add(btns[3], BorderLayout.CENTER);
		action(btns[3],4);
		
		ph[1][19].add(btns[4], BorderLayout.CENTER);
		action(btns[4],5);
		
		ph[2][1].add(btns[5], BorderLayout.CENTER);
		action(btns[5],6);
		
		ph[2][17].add(btns[6], BorderLayout.CENTER);
		action(btns[6],7);
		
		ph[2][18].add(btns[7], BorderLayout.CENTER);
		action(btns[7],8);
		
		ph[2][19].add(btns[8], BorderLayout.CENTER);
		action(btns[8],9);
		
		ph[3][1].add(btns[9], BorderLayout.CENTER);
		action(btns[9],10);
		
		ph[3][11].add(btns[10], BorderLayout.CENTER);
		action(btns[10],11);
		
		ph[3][12].add(btns[11], BorderLayout.CENTER);
		action(btns[11],12);
		
		ph[3][13].add(btns[12], BorderLayout.CENTER);
		action(btns[12],13);
		
		ph[3][14].add(btns[13], BorderLayout.CENTER);
		action(btns[13],14);
		
		ph[3][15].add(btns[14], BorderLayout.CENTER);
		action(btns[14],15);
		
		ph[3][17].add(btns[15], BorderLayout.CENTER);
		action(btns[15],16);
		
		ph[3][18].add(btns[16], BorderLayout.CENTER);
		action(btns[16],17);
		
		ph[3][19].add(btns[17], BorderLayout.CENTER);
		action(btns[17],18);
		
		ph[4][1].add(btns[18], BorderLayout.CENTER);
		action(btns[18],19);
		
		ph[4][11].add(btns[19], BorderLayout.CENTER);
		action(btns[19],20);
		
		ph[4][12].add(btns[20], BorderLayout.CENTER);
		action(btns[20],21);
		
		ph[4][13].add(btns[21], BorderLayout.CENTER);
		action(btns[21],22);
		
		ph[4][14].add(btns[22], BorderLayout.CENTER);
		action(btns[22],23);
		
		ph[4][15].add(btns[23], BorderLayout.CENTER);
		action(btns[23],24);
		
		ph[4][17].add(btns[24], BorderLayout.CENTER);
		action(btns[24],25);
		
		ph[4][18].add(btns[25], BorderLayout.CENTER);
		action(btns[25],26);
		
		ph[4][19].add(btns[26], BorderLayout.CENTER);
		action(btns[26],27);
		
		ph[5][1].add(btns[27], BorderLayout.CENTER);
		action(btns[27],28);
		
		ph[5][3].add(btns[28], BorderLayout.CENTER);
		action(btns[28],29);
		
		ph[5][4].add(btns[29], BorderLayout.CENTER);
		action(btns[29],30);
		
		ph[5][5].add(btns[30], BorderLayout.CENTER);
		action(btns[30],31);
		
		ph[5][6].add(btns[31], BorderLayout.CENTER);
		action(btns[31],32);
		
		ph[5][7].add(btns[32], BorderLayout.CENTER);
		action(btns[32],33);
		
		ph[5][8].add(btns[33], BorderLayout.CENTER);
		action(btns[33],34);
		
		ph[5][9].add(btns[34], BorderLayout.CENTER);
		action(btns[34],35);
		
		ph[5][11].add(btns[35], BorderLayout.CENTER);
		action(btns[35],36);
		
		ph[5][12].add(btns[36], BorderLayout.CENTER);
		action(btns[36],37);
		
		ph[5][13].add(btns[37], BorderLayout.CENTER);
		action(btns[37],38);
		
		ph[5][14].add(btns[38], BorderLayout.CENTER);
		action(btns[38],39);
		
		ph[5][15].add(btns[39], BorderLayout.CENTER);
		action(btns[39],40);
		
		ph[5][17].add(btns[40], BorderLayout.CENTER);
		action(btns[40],41);
		
		ph[5][18].add(btns[41], BorderLayout.CENTER);
		action(btns[41],42);
		
		ph[5][19].add(btns[42], BorderLayout.CENTER);
		action(btns[42],43);
		
		ph[6][1].add(btns[43], BorderLayout.CENTER);
		action(btns[43],44);

		ph[6][3].add(btns[44], BorderLayout.CENTER);
		action(btns[44],45);
		
		ph[6][4].add(btns[45], BorderLayout.CENTER);
		action(btns[45],46);
		
		ph[6][5].add(btns[46], BorderLayout.CENTER);
		action(btns[46],47);
		
		ph[6][6].add(btns[47], BorderLayout.CENTER);
		action(btns[47],48);
		
		ph[6][7].add(btns[48], BorderLayout.CENTER);
		action(btns[48],49);
		
		ph[6][8].add(btns[49], BorderLayout.CENTER);
		action(btns[49],50);
		
		ph[6][9].add(btns[50], BorderLayout.CENTER);
		action(btns[50],51);
		
		ph[6][11].add(btns[51], BorderLayout.CENTER);
		action(btns[51],52);
		
		ph[6][12].add(btns[52], BorderLayout.CENTER);
		action(btns[52],53);
		
		ph[6][13].add(btns[53], BorderLayout.CENTER);
		action(btns[53],54);
		
		ph[6][14].add(btns[54], BorderLayout.CENTER);
		action(btns[54],55);
		
		ph[6][15].add(btns[55], BorderLayout.CENTER);
		action(btns[55],56);
		
		ph[6][17].add(btns[56], BorderLayout.CENTER);
		action(btns[56],57);
		
		ph[6][18].add(btns[57], BorderLayout.CENTER);
		action(btns[57],58);
		
		ph[6][19].add(btns[58], BorderLayout.CENTER);
		action(btns[58],59);
		
		add(jp1);
		
		jl3 = new JLabel("                                         ");
		jl3.setFont(new Font("Monoco", Font.BOLD, 45));
		add(jl3);
	}
	
	protected void action(ElectrongBtn btn, int num) {
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!btn.getState()) {
					System.out.println((num*2)-1);
					curEle = (num*2)-1;
				} else if(btn.getState() && !btn.getState2()) {
					System.out.println((num*2));
					curEle = (num*2);
				} else {
					System.out.println((num*2)-1);
					curEle = (num*2)-1;
				}
				for(int i = 0; i < num-1; i++) {
					btns[i].activate2();
				} for(int i = btns.length-1; i > num-1; i--) {
					btns[i].deactivate();
				}
				
				elecConfig(curEle);
				
			}
		});
	}
	
	private void elecConfig(int num) {
		String config = "";
		if(num >= 2) {
			config += "1s^2";
			if(num >= 4) {
				config += ", 2s^2";
				if(num >= 10) {
					config += ", 2p^6";
					if(num >= 12) {
						config += ", 3s^2";
						if(num >= 18) {
							config += ", 3p^6";
							if(num >= 20) {
								config += ", 4s^2";
								if(num >= 30) {
									config += ", 3d^10";
									if(num >= 36) {
										config += ", 4p^6";
										if(num >= 38) {
											config += ",<br>5s^2";
											config = String.format("<html><p>%s</p></html>", config);
										} else if (num > 36) {
											config += ",<br>5s^1";
											config = String.format("<html><p>%s</p></html>", config);
										}
									} else if(num > 30) {
										config += (", 4p^"+(num-30));
									}
								} else if(num > 20) {
									config += (", 3d^" + (num-20));
								}
							} else if(num > 18) {
								config += ", 4s^1";
							}
						} else if (num > 12) {
							config += (", 3p^" + (num-12));
						}
					} else if(num > 10) {
						config += ", 3s^1";
					}
				} else if (num > 4) {
					config += (", 2p^" + (num-4));
				}
			} else if(num > 2) {
				config += ", 2s^1";
			}
		} else {
			config += "1s^1";
		}
		jl3.setText(config);
	}
	
}