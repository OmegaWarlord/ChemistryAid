package main;

public class Main {

	public static void main(String[] args) {
		GraphicsRunner g = new GraphicsRunner();
	}
}