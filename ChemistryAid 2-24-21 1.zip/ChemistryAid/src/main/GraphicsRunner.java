package main;

import javax.swing.*;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import java.awt.*;
import java.awt.event.*;



public class GraphicsRunner extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private static final int WIDTH = 1100;
	private static final int HEIGHT = 700;
	
	private JTabbedPane tp;
	private JLabel ptl;
	private PeriodicTablePannel pt;
	private JLabel mcl;
	private MolecularCalculationsPannel mc;
	private JLabel ecl;
	private ElectronConfigurationPannel ec;


	
	public GraphicsRunner(){
		super("Graphics Runner");
		setSize(WIDTH,HEIGHT);
		
		UIManager.put("TabbedPane.selected", Color.LIGHT_GRAY);
		UIManager.put("TabbedPane.background", Color.GRAY);
		UIManager.put("TabbedPane.contentAreaColor", Color.LIGHT_GRAY);
		
		setTitle("Chemistry Aid | Dev Build");
		
		tp = new JTabbedPane();
		
		tp.setUI(new BasicTabbedPaneUI() {
			@Override
			protected void installDefaults() {
				super.installDefaults();
			    highlight = Color.GRAY;
			    lightHighlight = Color.GRAY;
			    shadow = Color.LIGHT_GRAY;
			    darkShadow = Color.GRAY;
			    focus = Color.LIGHT_GRAY;
		   }
		});
		
		pt = new PeriodicTablePannel(this);
		ptl = new JLabel("Periodic Table");
		ptl.setFont(new Font("Monaco", Font.BOLD, 15));
		tp.addTab("Periodic Table", null, pt, "Period Table");
		tp.setTabComponentAt(0, ptl);
		tp.setMnemonicAt(0, KeyEvent.VK_1);
		
		ec = new ElectronConfigurationPannel(this);
		ecl = new JLabel("Electron Configuration");
		ecl.setFont(new Font("Monaco", Font.BOLD, 15));
		tp.addTab("Electron Configuration", null, ec, "Electron Configuration");
		tp.setTabComponentAt(1, ecl);
		tp.setMnemonicAt(1, KeyEvent.VK_2);
		
		mc = new MolecularCalculationsPannel(this);
		mcl = new JLabel("Molecular Calculations");
		mcl.setFont(new Font("Monaco", Font.BOLD, 15));
		tp.addTab("Molecular Calculations", null, mc, "Molecular Calculations");
		tp.setTabComponentAt(2, mcl);
		tp.setMnemonicAt(2, KeyEvent.VK_3);
		
		tp.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		
	    add(tp);
	   
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}